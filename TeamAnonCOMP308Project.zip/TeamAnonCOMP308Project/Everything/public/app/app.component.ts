﻿import { Component } from '@angular/core';

@Component({
    selector: 'mean-app',
    templateUrl: './app/app.template.html',
})
export class AppComponent { }
