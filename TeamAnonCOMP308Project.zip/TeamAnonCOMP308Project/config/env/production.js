﻿// Set the 'production' environment configuration object
module.exports = {
    db: 'mongodb://localhost/comp308-final-prod',
    sessionSecret: 'productionSessionSecret',
};