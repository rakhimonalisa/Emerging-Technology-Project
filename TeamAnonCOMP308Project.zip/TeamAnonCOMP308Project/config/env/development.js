﻿// Set the 'development' environment configuration object
module.exports = {
    db: 'mongodb://localhost/comp308-final-dev',
    sessionSecret: 'developmentSessionSecret',
};