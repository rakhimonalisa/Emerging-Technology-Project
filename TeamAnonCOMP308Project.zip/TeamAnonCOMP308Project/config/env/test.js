﻿// Set the 'test' environment configuration object
module.exports = {
    db: 'mongodb://localhost/comp308-final-test',
    sessionSecret: 'testSessionSecret',
};